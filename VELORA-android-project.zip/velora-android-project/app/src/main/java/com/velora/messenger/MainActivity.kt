package com.velora.messenger

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val bg = Color.rgb(17, 18, 20)
    private val panel = Color.rgb(27, 29, 32)
    private val muted = Color.rgb(153, 157, 165)
    private val lime = Color.rgb(198, 243, 106)
    private val white = Color.rgb(244, 245, 247)
    private val prefs by lazy { getSharedPreferences("velora", MODE_PRIVATE) }
    private val chats = mutableListOf<Chat>()
    private lateinit var list: LinearLayout
    private lateinit var subtitle: TextView
    private var active: Chat? = null

    data class Chat(val name: String, val kind: String, val messages: MutableList<String> = mutableListOf())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        loadChats()
        if (chats.isEmpty()) {
            chats.add(Chat("Личные заметки", "Личное", mutableListOf("Добро пожаловать в VELORA.", "Это ваше личное офлайн-пространство.")))
            chats.add(Chat("Тихая гавань", "Группа", mutableListOf("Здесь можно проверить переписку.")))
            chats.add(Chat("VELORA / Новости", "Канал", mutableListOf("Канал создан. Публикации хранятся на устройстве.")))
            saveChats()
        }
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun base(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(20), dp(14), dp(20), dp(12)) }
    private fun button(label: String, onClick: () -> Unit): TextView = text(label, 15f, bg, true).apply {
        gravity = Gravity.CENTER; background = shape(lime, 15); setPadding(dp(15), dp(13), dp(15), dp(13)); setOnClickListener { onClick() }
    }
    private fun showHome() {
        active = null
        val root = base()
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        brand.addView(text("◈  VELORA", 28f, white, true))
        brand.addView(text("YOUR SPACE. YOUR RULES.", 10f, muted, true))
        top.addView(brand)
        top.addView(button("＋", ::showCreateDialog).apply { textSize = 24f; layoutParams = LinearLayout.LayoutParams(dp(54), dp(50)) })
        root.addView(top)
        val search = EditText(this).apply {
            hint = "Поиск по чатам"; setHintTextColor(muted); setTextColor(white); textSize = 15f
            background = shape(panel, 15); setPadding(dp(14), 0, dp(14), 0); singleLine = true
        }
        val searchParams = LinearLayout.LayoutParams(-1, dp(48)); searchParams.topMargin = dp(24); root.addView(search, searchParams)
        val heading = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val headingText = text("Ваши пространства", 20f, white, true)
        heading.addView(headingText, LinearLayout.LayoutParams(0, -2, 1f)); heading.addView(text("${chats.size}", 14f, lime, true))
        val hp = LinearLayout.LayoutParams(-1, -2); hp.topMargin = dp(26); hp.bottomMargin = dp(12); root.addView(heading, hp)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val bottom = text("ЛОКАЛЬНОЕ ХРАНЕНИЕ  ·  БЕЗ СЕРВЕРА", 10f, muted, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(15), 0, dp(6)) }
        root.addView(bottom)
        setContentView(root)
        renderChats()
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderChats(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun renderChats(filter: String = "") {
        list.removeAllViews()
        chats.filter { it.name.contains(filter, true) || it.kind.contains(filter, true) }.forEach { chat ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = shape(panel, 18); setPadding(dp(12), dp(12), dp(12), dp(12)) }
            val avatar = TextView(this).apply {
                text = when(chat.kind) { "Канал" -> "↗"; "Группа" -> "◎"; else -> "✳" }
                textSize = 22f; setTextColor(bg); gravity = Gravity.CENTER; background = shape(lime, 15)
            }
            row.addView(avatar, LinearLayout.LayoutParams(dp(50), dp(50)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            info.addView(text(chat.name, 16f, white, true))
            val preview = chat.messages.lastOrNull() ?: "Пока нет сообщений"
            info.addView(text("${chat.kind}  ·  $preview", 12f, muted).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.setOnClickListener { openChat(chat) }
            val p = LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(10); list.addView(row, p)
        }
    }

    private fun showCreateDialog() {
        val options = arrayOf("Личная заметка", "Создать группу", "Создать канал")
        AlertDialog.Builder(this).setTitle("Новое пространство").setItems(options) { _, which ->
            val kind = when(which) { 1 -> "Группа"; 2 -> "Канал"; else -> "Личное" }
            val input = EditText(this).apply { hint = when(kind) { "Группа" -> "Название группы"; "Канал" -> "Название канала"; else -> "Название заметки" }; setTextColor(white); setHintTextColor(muted) }
            AlertDialog.Builder(this).setTitle("Создать: $kind").setView(input).setNegativeButton("Отмена", null).setPositiveButton("Создать") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) { val c = Chat(name, kind); chats.add(0, c); saveChats(); showHome() }
            }.show()
        }.show()
    }

    private fun openChat(chat: Chat) {
        active = chat
        val root = base()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(text("‹", 34f, lime).apply { setPadding(0, 0, dp(18), 0); setOnClickListener { showHome() } })
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        names.addView(text(chat.name, 20f, white, true)); names.addView(text("${chat.kind} · только на этом устройстве", 11f, muted))
        top.addView(names)
        root.addView(top)
        val messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this); scroll.addView(messages)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        fun refreshMessages() {
            messages.removeAllViews()
            chat.messages.forEachIndexed { i, message ->
                val bubble = TextView(this).apply { text = message; textSize = 15f; setTextColor(white); background = shape(if (i % 2 == 0) panel else Color.rgb(45, 54, 37), 16); setPadding(dp(14), dp(11), dp(14), dp(11)) }
                val p = LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(7); p.bottomMargin = dp(3); messages.addView(bubble, p)
            }
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
        refreshMessages()
        val composer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(this).apply { hint = if (chat.kind == "Канал") "Новая публикация…" else "Сообщение…"; setHintTextColor(muted); setTextColor(white); textSize = 14f; background = shape(panel, 16); setPadding(dp(13), 0, dp(13), 0); singleLine = true; imeOptions = EditorInfo.IME_ACTION_SEND }
        composer.addView(input, LinearLayout.LayoutParams(0, dp(50), 1f))
        val send = button("➤") { val value = input.text.toString().trim(); if (value.isNotEmpty()) { chat.messages.add(value); input.setText(""); saveChats(); refreshMessages() } }
        val bp = LinearLayout.LayoutParams(dp(54), dp(50)); bp.leftMargin = dp(8); composer.addView(send, bp)
        input.setOnEditorActionListener { _, action, _ -> if (action == EditorInfo.IME_ACTION_SEND) { send.performClick(); true } else false }
        val cp = LinearLayout.LayoutParams(-1, -2); cp.topMargin = dp(10); root.addView(composer, cp)
        setContentView(root)
    }

    private fun saveChats() {
        val array = JSONArray()
        chats.forEach { c -> array.put(JSONObject().put("name", c.name).put("kind", c.kind).put("messages", JSONArray(c.messages))) }
        prefs.edit().putString("chats", array.toString()).apply()
    }
    private fun loadChats() {
        try {
            val array = JSONArray(prefs.getString("chats", "[]"))
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i); val msgs = o.optJSONArray("messages") ?: JSONArray(); val list = mutableListOf<String>()
                for (j in 0 until msgs.length()) list.add(msgs.optString(j))
                chats.add(Chat(o.optString("name"), o.optString("kind", "Личное"), list))
            }
        } catch (_: Exception) { chats.clear() }
    }
}
