# VELORA Android

Native Kotlin Android prototype for offline use. Features: local chat spaces, creation of personal notes/groups/channels, local messages and persistence using SharedPreferences. No network/server code is included; messages are only stored on this device.

## Build
Run `gradle assembleDebug` with JDK 17 and Android SDK platform 35 installed. Output: `app/build/outputs/apk/debug/app-debug.apk`.
